//
//  Structs.swift
//  muy_cbl3_grupo11
//
//  Created by Aluno Mack on 15/04/25.
//

import SwiftUI


struct Food: Identifiable {
    var id: Int
    let name: String
    let description: String
    let price: String
    let imageName: String
}

struct NewFood: Identifiable {
    var id: Int
    let name: String
    let price: String
    let imageName: String
}

struct Banner: Identifiable {
    var id: Int
    let imageName: String
}










struct Structs: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

//#Preview {
//    Structs()
//}
