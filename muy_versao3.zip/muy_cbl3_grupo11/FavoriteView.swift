import SwiftUI

struct FavoriteView: View {
    var body: some View {
        Text("Favoritos")
            .foregroundStyle(.verdeEscuro)
    }
}

#Preview {
    FavoriteView()
}
