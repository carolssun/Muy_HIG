import SwiftUI

struct HomeView: View {
    @State var isShowing: Bool = false
    @State var cartSymbol = Image(systemName: "cart")
    @State var color = Color.verdeEscuro
    @State var selectedTabs = 0
    
    let rows = [
        GridItem(.fixed(32)),
        GridItem(.fixed(32)),
        GridItem(.fixed(32)),
        GridItem(.fixed(32))
    ]
    
    let newRows = [
        GridItem(.fixed(32))
    ]
    
    
    
    @State var foodOptions = [
        Food (id: 1 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        Food (id: 2 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        Food (id: 3 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        Food (id: 4 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        Food (id: 5 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        Food (id: 6 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        Food (id: 7 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        Food (id: 8 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        Food (id: 9 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "burritoAngus" ),
        
    ]
    
    @State var newFood = [
        NewFood (id: 1, name: "Enchilada de pollo", price: "R$ 59,90", imageName: "enchiladaFrango" ),
        NewFood (id: 2, name: "Enchilada de pollo", price: "R$ 59,90", imageName: "enchiladaFrango" ),
        NewFood (id: 3, name: "Enchilada de pollo", price: "R$ 59,90", imageName: "enchiladaFrango" ),
        NewFood (id: 4, name: "Enchilada de pollo", price: "R$ 59,90", imageName: "enchiladaFrango" ),
        NewFood (id: 5, name: "Enchilada de pollo", price: "R$ 59,90", imageName: "enchiladaFrango" ),
        NewFood (id: 6, name: "Enchilada de pollo", price: "R$ 59,90", imageName: "enchiladaFrango" ),
        NewFood (id: 7, name: "Enchilada de pollo", price: "R$ 59,90", imageName: "enchiladaFrango" ),
        NewFood (id: 8, name: "Enchilada de pollo", price: "R$ 59,90", imageName: "enchiladaFrango" ),
        
    ]
    
    @State var bannerAd = [
        Banner (id:1, imageName: "bannerAd1"),
        Banner (id:2, imageName: "bannerAd2"),
        Banner (id:3, imageName: "bannerAd1"),
        Banner (id:4, imageName: "bannerAd2"),
    ]
    
    @State var dessert = [
        NewFood (id: 1, name: "Churros com sorvete", price: "R$ 30,00", imageName: "churros" ),
        NewFood (id: 2, name: "Churros com sorvete", price: "R$ 30,00", imageName: "churros" ),
        NewFood (id: 3, name: "Churros com sorvete", price: "R$ 30,00", imageName: "churros" ),
        NewFood (id: 4, name: "Churros com sorvete", price: "R$ 30,00", imageName: "churros" ),
        NewFood (id: 5, name: "Churros com sorvete", price: "R$ 30,00", imageName: "churros" ),
        NewFood (id: 6, name: "Churros com sorvete", price: "R$ 30,00", imageName: "churros" ),
        NewFood (id: 7, name: "Churros com sorvete", price: "R$ 30,00", imageName: "churros" ),
        NewFood (id: 8, name: "Churros com sorvete", price: "R$ 30,00", imageName: "churros" ),
        
    ]
    
    var body: some View {
        VStack{
            HStack{
                Button("Menu"){}
                    .padding(.leading)
                    .foregroundColor(.verdeEscuro)
                
                Spacer()
                
                
                Picker( "tabs", selection: $selectedTabs){
                    Text("Destaque").tag(0)
                    Text("Favoritos").tag(1)
                }
                
                
                Button("\(cartSymbol)"){
                    isShowing.toggle()
                }
                .foregroundColor(.verdeEscuro)
                .sheet(isPresented: $isShowing){
                    CartView()
                        .presentationDetents([.large])
                }
                
                .padding(.trailing)
                
                
            }
            .pickerStyle(.segmented)
            .padding(.horizontal)
            //            Spacer()
            
            ScrollView {
                
                if selectedTabs == 0 {
                    // COLOCAR AQUI TUDO DESSA PÁGINA!!!!
                    
                    
                    
                    
                    // criar
                    Section {
                        HStack {
                            Text("Novidades")
                                .padding(.horizontal)
                                .font(.system(size: 15))
                            Spacer()
                        }
                        HStack{
                            ScrollView(.horizontal,showsIndicators: false) {
                                
                                LazyHGrid(rows: newRows){
                                    ForEach(newFood){ food in
                                        
                                        VStack{
                                            
                                            Image(food.imageName)
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 80, height: 80)
                                            Text(food.name)
                                                .frame(width: 70)
                                                .font(.system(size: 10))
                                            
                                            Text(food.price)
                                                .foregroundStyle(.gray)
                                                .font(.system(size: 8))
                                            
                                            
                                        }
                                    }
                                    
                                }
                                
                            }
                            .padding(.horizontal)
                        }
                    }
                    Section {
                        
                        HStack {
                            Text("Últimos pedidos")
                                .padding(.horizontal)
                                .font(.system(size: 15))
                            Spacer()
                        }
                        ScrollView(.horizontal,showsIndicators: false) {
                            
                            LazyHGrid(rows: rows){
                                ForEach(foodOptions){ food in
                                    
                                    HStack{
                                        Button{
                                            
                                        }label: {
                                            Image(food.imageName)
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 60, height: 50)
                                            
                                            VStack(alignment:.leading){
                                                Text(food.name)
                                                    .font(.system(size: 10))
                                                    .foregroundStyle(.black)
                                                
                                                Text(food.description)
                                                    .foregroundStyle(.gray)
                                                    .font(.system(size: 8))
                                            }
                                            
                                        }
                                        
                                        .padding(.horizontal)
                                        //                                    Spacer()
                                        
                                        Button{
                                            
                                        } label:{
                                            
                                            Text(food.price)
                                                .font(.system(size: 12))
                                                .padding(5)
                                                .accentColor(.verdeEscuro)
                                                .frame(width: 63, height: 20)
                                            
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 3)
                                                        .stroke(.verdeEscuro, lineWidth: 1)
                                                )
                                            
                                            
                                        }
                                        .padding(.horizontal, 25)
                                    }
                                }
                            }
                        }
                    }
                    
                    
                    Section{
                        ScrollView(.horizontal, showsIndicators: false) {
                            
                            LazyHGrid(rows: newRows){
                                ForEach(bannerAd){ banner in
                                    
                                    VStack{
                                        Button{
                                            print(" ")
                                        } label: {
                                            Image(banner.imageName)
                                                .resizable()
                                                .scaledToFill()
                                                .frame(width: 150, height: 70)
                                                .padding(1)
                                        }
                                    }
                                    .padding(.leading)
                                }
                            }
                        }
                    }
                    
                    Section {
                        HStack {
                            Text("Sobremesas")
                                .padding(.horizontal)
                                .font(.system(size: 15))
                            Spacer()
                        }
                        HStack {
                            ScrollView(.horizontal,showsIndicators: false) {
                                
                                LazyHGrid(rows: newRows){
                                    ForEach(dessert){ food in
                                        
                                        VStack{
                                            
                                            Image(food.imageName)
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 80, height: 80)
                                            Text(food.name)
                                                .frame(width: 70)
                                                .font(.system(size: 10))
                                            
                                            Text(food.price)
                                                .foregroundStyle(.gray)
                                                .font(.system(size: 8))
                                            
                                            
                                        }
                                        //.padding(.horizontal, 5)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    
                    // adicionar aqui as outras repetições
                    
                    Section{
                        VStack(spacing: 10){
                            HStack{
                                Text("Links Rápidos")
                                    .padding(.horizontal)
                                    .font(.system(size: 15))
                                Spacer()
                            }
                            Button {
                                
                            }label:{Text("Comunidade")
                                    .font(.system(size: 15))
                            }
                            Button {
                                
                            }label:{Text("Avaliar")
                                    .font(.system(size: 15))
                            }
                            Button {
                                
                            }label:{Text("Fidelidade")
                                    .font(.system(size: 15))
                            }
                            Button {
                                
                            }label:{Text("Doações")
                                    .font(.system(size: 15))
                            }
                            Button {
                                
                            }label:{Text("Entre em contato conosco")
                                    .font(.system(size: 15))
                            }
                            Button {
                                
                            }label:{Text("Sobre nós")
                                    .font(.system(size: 15))
                            }
                            
                            Button {}label:{
                                ZStack{
                                    Text("Ajuda")
                                        .foregroundStyle(.gray)
                                        .font(.system(size: 12))
                                        .padding(5)
                                        .frame(width:370)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 5)
                                                .stroke(.gray, lineWidth: 1)
                                            
                                        )
                                }
                                
                            }
                            Button {}label:{
                                ZStack{
                                    Text("Configurações")
                                        .foregroundStyle(.gray)
                                        .font(.system(size: 12))
                                        .padding(5)
                                        .frame(width:370)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 5)
                                                .stroke(.gray, lineWidth: 1)
                                            
                                        )
                                }
                                
                            }
                            Button {}label:{
                                ZStack{
                                    Text("Políticas de devolução")
                                        .foregroundStyle(.gray)
                                        .font(.system(size: 10))
                                        .padding(5)
                                    //Image()
                                }
                                
                            }
                            
                        }
                    }
                    
                    
                    
                    
                }else{
                    Text("Ainda em manutenção")
                }
            }
        }
    }
}

#Preview {
    HomeView()
}
