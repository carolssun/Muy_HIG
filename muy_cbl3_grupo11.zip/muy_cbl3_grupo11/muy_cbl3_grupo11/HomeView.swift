import SwiftUI

struct HomeView: View {
    @State var isShowing: Bool = false
    @State var cartSymbol = Image(systemName: "cart")
    @State var color = Color.verdeEscuro
    @State var selectedTabs = 0
    
    
    
    var body: some View {
        
        //        ZStack{
        //            VStack{
        //                HStack{
        //                    Button(" \(cartSymbol)" ) {
        //                        isShowing.toggle()
        //                    }
        //
        //
        //                    .sheet(isPresented: $isShowing){
        //                        CartView()
        //                            .presentationDetents([.large])
        //                    }
        //                }
        //                .padding(.leading)
        //
        //            }
        //
        //        }
        
        HStack{
            Button("Menu"){}
                .padding(.leading)
                .foregroundColor(.verdeEscuro)
            
            Spacer()
            
            
            Picker( "tabs", selection: $selectedTabs){
                Text("Destaque").tag(0)
                Text("Favoritos").tag(1)
            }
            
            
            Button("\(cartSymbol)"){
                isShowing.toggle()
            }
                .sheet(isPresented: $isShowing){
                    CartView()
                        .presentationDetents([.large])
                }
            
                .padding(.trailing)
                .bold()
                .foregroundColor(.verdeEscuro)
        
        }
        .pickerStyle(.segmented)
        .padding(.horizontal)
        Spacer()
        
        
        if selectedTabs == 0 {
            // COLOCAR AQUI TUDO DESSA PÁGINA!!!!
            
            
            
            @State var foodOptions = [
                Food (id: 1, name: "Fajita de camarão", description: "Acompanha salsa, guacamole...", price: "R$ 72,00", imageName: "fajitaCamarao" ),
                Food (id: 2 , name: "Burrito Angus Mex", description: "suculentas tiras de angus", price: "R$ 60,00", imageName: "BurritoAngos" ),
                Food (id: 3, name: "Quesadilla", description: "tem queijo", price: "R$ 45,00", imageName: "quesadilla"),
                Food (id: 4, name: "Nachos Veggie", description: "receita tradicional texana", price: "R$ 42,00", imageName: "nachoVeggie" )
               
                
            ]
            
            HStack{
                
                List {
                    ForEach (foodOptions){ food in
                        HStack{
                            Image(food.imageName)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 40, height: 40)
                            VStack(alignment:.leading){
                                Text(food.name)
                                    .font(.system(size: 15))
                                
                                Text(food.description)
                                    .font(.system(size: 10))
                                
                            }
                            .padding()
                            Spacer()
                            
                            Button{
                                
                            } label:{
                                
                                Text(food.price)
                                    .font(.system(size: 12))
                                    .padding(5)
                                    .accentColor(.verdeEscuro)
                                    .frame(width: 63, height: 25)
                                
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 3)
                                            .stroke(.verdeEscuro, lineWidth: 1)
                                    )
                                
                                
                            }
                        }
                    }
                }
                
            }
            
        }else{
            Text("Ainda em manutenção")
        }
        Spacer()
        
    }
}

#Preview {
    HomeView()
}
