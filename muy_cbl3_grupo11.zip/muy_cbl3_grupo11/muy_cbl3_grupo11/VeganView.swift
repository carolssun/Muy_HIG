import SwiftUI

struct VeganView: View {
    var body: some View {
        Text("Alface")
    }
}

#Preview {
    VeganView()
}
