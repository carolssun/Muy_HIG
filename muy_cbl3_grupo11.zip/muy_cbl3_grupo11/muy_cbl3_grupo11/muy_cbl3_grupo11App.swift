//
//  muy_cbl3_grupo11App.swift
//  muy_cbl3_grupo11
//
//  Created by Aluno Mack on 14/04/25.
//

import SwiftUI

@main
struct muy_cbl3_grupo11App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
