//
//  ProfileView.swift
//  marolina_CBL3
//
//  Created by Aluno Mack on 10/04/25.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("Perfil")
    }
}

#Preview {
    ProfileView()
}
